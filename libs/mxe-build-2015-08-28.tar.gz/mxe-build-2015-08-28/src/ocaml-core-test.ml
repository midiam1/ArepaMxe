(*
This file is part of MXE.
See index.html for further information.
*)

open Printf
open Format
let _ =
  ignore (1+2)
